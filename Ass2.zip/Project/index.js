let arr=["Wasim","Saurabh","Naresh","Suresh"]
console.log(`Actual Araay: ${arr}`)
console.log("Printing All Elements In Reverse:")
console.log(`Reverse Array : ${arr.reverse()}`);


let a =1;
while (a<=50){
  if (a%5==0){
    console.log(a)
  }
  a++;
}